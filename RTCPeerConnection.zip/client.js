let connection = new WebSocket('ws://localhost:9090');
let name = "";
let loginInput = document.querySelector('#loginInput');
let loginBtn = document.querySelector('#loginBtn');
let otherUsernameInput = document.querySelector('#otherUsernameInput');
let connectToOtherUsernameBtn = document.querySelector('#connectToOtherUsernameBtn');
let connectedUser, myConnection;

//when a user clicks the login button
loginBtn.addEventListener("click", function(event){
    name = loginInput.value;
    if(name.length > 0){
        send({
            type: "login",
            name: name
        });
    }
});

//handle messages from the server
connection.onmessage = function (message) {
    console.log("Got message", message.data);
    let data = JSON.parse(message.data);
    switch(data.type) {
        case "login":
            onLogin(data.success);
            break;
        case "offer":
            onOffer(data.offer, data.name);
            break;
        case "answer":
            onAnswer(data.answer);
            break;
        case "candidate":
            onCandidate(data.candidate);
            break;
        default:
            break;
    }
};

//when a user logs in
function onLogin(success) {
    if (success === false) {
        alert("oops...try a different username");
    } else {
        //creating our RTCPeerConnection object
        let configuration = {
            "iceServers": [{ "url": "stun:stun.1.google.com:19302" }]
        };
        myConnection = new webkitRTCPeerConnection(configuration);
        console.log("RTCPeerConnection object was created");
        console.log(myConnection);
        //setup ice handling
        //when the browser finds an ice candidate we send it to another peer
        myConnection.onicecandidate = function (event) {
            if (event.candidate) {
                send({
                    type: "candidate",
                    candidate: event.candidate
                });
            }
        };
    }
};

connection.onopen = function () {
    console.log("Connected");
};

connection.onerror = function (err) {
    console.log("Got error", err);
};

// Alias for sending messages in JSON format
function send(message) {
    if (connectedUser) {
        message.name = connectedUser;
    }
    connection.send(JSON.stringify(message));
};